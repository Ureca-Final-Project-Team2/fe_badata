export interface UserDataUsage {
  used: number;
}
