export interface UserDataUsage {
  used: number;
  total: number;
}
