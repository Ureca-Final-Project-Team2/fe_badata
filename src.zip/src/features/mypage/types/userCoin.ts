export interface UserCoin {
  coin: number;
}
