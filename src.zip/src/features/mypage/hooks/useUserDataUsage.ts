import { useQuery } from '@tanstack/react-query';
import { fetchUserDataUsage } from '../apis/fetchUserDataUsage';
import { UserDataUsage } from '../types/userDataUsage';

export const useUserDataUsage = () => {
  return useQuery<UserDataUsage>({
    queryKey: ['userDataUsage'],
    queryFn: fetchUserDataUsage,
  });
};
