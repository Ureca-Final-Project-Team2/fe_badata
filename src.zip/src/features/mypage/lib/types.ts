export interface UserCoin {
  amount: number;
}

export interface UserDataUsage {
  total: number;
  used: number;
  remaining: number;
}

export interface SosHistoryItem {
  id: number;
  createdAt: string;
  imageUrl: string;
  merchantName: string;
  menuName: string;
  price: number;
}
