import { axiosInstance } from '@/shared/lib/axios/axiosInstance';
import { UserDataUsage } from '../types/userDataUsage';

interface ApiResponse<T> {
  code: number;
  message: string | null;
  content: T;
}

export const fetchUserDataUsage = async (): Promise<UserDataUsage> => {
  const response = await axiosInstance.get<ApiResponse<UserDataUsage>>('/api/v1/users/data');
  console.log('[API 요청] fetchUserDataUsage', response.data);
  return response.data.content;
};
