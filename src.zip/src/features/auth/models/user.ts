export interface User {
  userId: number;
  email: string;
  name: string;
  profile_image_url: string;
  newUser: boolean;
}
