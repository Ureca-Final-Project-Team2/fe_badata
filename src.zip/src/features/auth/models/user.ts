export interface User {
  email: string;
  name: string;
  profile_image_url: string;
  newUser: boolean;
}
