'use client';

import { MyDataUsageCard } from '@/features/mypage/ui/MyDataUsageCard';
import { MyPageHeader } from '@/features/mypage/ui/MyPageHeader';
import { MyRentalSection } from '@/features/mypage/ui/section/MyRentalSection';
import { MyReportStatus } from '@/features/mypage/ui/section/MyReportStatus';
import { MySettings } from '@/features/mypage/ui/section/MySettings';
import { MySosSection } from '@/features/mypage/ui/section/MySosSection';
import { MyTradeSection } from '@/features/mypage/ui/section/MyTradeSection';
import { BaseLayout } from '@components/layout/BaseLayout';
import { Header } from '@ui/Header';

export default function MyPage() {
  return (
    <BaseLayout header={<Header />}>
      <div className="space-y-6">
        <MyPageHeader />
        <MyDataUsageCard />
        <MyTradeSection />
        <MyRentalSection />
        <MySosSection />
        <MyReportStatus />
        <MySettings />
      </div>
    </BaseLayout>
  );
}
