import MyCoinPage from "@/features/mypage/pages/MyCoinPage";

export default function Page() {
  return <MyCoinPage />;
}