import { SosHistoryList } from "@/features/mypage/pages/MySosPage";

export default function Page() {
  return <SosHistoryList />;
}