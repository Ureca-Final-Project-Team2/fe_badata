'use client';

import TradeMainPage from '@features/trade/pages/TradeMainPage';

export default function Page() {
  return <TradeMainPage />;
}
