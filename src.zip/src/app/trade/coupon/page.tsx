'use client';

import TradeCouponPage from '@features/trade/pages/TradeCouponPage';

export default function Page() {
  return <TradeCouponPage />;
}
