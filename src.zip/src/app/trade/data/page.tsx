'use client';

import TradeDataPage from '@features/trade/pages/TradeDataPage';

export default function Page() {
  return <TradeDataPage />;
}
